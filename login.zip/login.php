<?php
$id = $_POST["idd"];
$pw = $_POST["pw"];

if(!$id){
    echo("
    <script>
        window.alert('아이디를 입력하세요');
        history.go(-1);
    </script>
    ");
    exit;
}
if(!$pw){
    echo("
    <script>
        window.alert('비밀번호를 입력하세요');
        history.go(-1);
    </script>
    ");
    exit;
}
echo "<strong>{$id}</strong> 님 환영합니다."
// DB 연결
$con = mysqli_connect("localhost", "root", "root"); // 데이터베이스 연결
// DB 선택
mysqli_select_db("test", $con);  // (데이터베이스 이름, 데이터베이스 연결 값)
// 쿼리문 실행
$sql = "select * from member where id = '$id'";
$result = mysqli_query($sql);
// 레코드 갯수
$num = mysqli_num_rows($result);

while($row = mysqli_fetch_array($result)){
    // index 안에 숫자, 그 열의 제목 가능
    // row행의 열 번호를 하나씩 끌어옴
    echo("
        <tr>
            <td>$row[0]</td>
            <td>$row[1]</td>
            <td>$row[2]</td>
            <td>$row[3]</td>
        </tr>
        "
    );
}
// DB 종료
mysqli_close();

?>