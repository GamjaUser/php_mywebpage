<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="check_proc.php" method="post">
        학번 입력 : <input type="text" name="id">&nbsp<input type="submit" value="출석">
    </form>
</body>
</html>